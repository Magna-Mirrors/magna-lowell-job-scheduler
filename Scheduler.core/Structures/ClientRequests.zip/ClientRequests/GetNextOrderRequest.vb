﻿Public Class GetNextOrderRequest
    Public Property LineId As Integer
End Class
