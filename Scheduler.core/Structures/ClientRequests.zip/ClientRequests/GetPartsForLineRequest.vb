﻿<DataContract()>
Public Class GetPartsForLineRequest
    <DataMember()>
    Public Property LineData As Line

End Class
