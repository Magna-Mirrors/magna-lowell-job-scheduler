﻿<DataContract()>
Public Class GetScheduleRequest
    <DataMember()>
    Public Property LineId As Integer

End Class