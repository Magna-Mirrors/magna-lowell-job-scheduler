﻿<DataContract()>
Public Class RemoveOrderRequest
    <DataMember>
    Public Property OrderId As Integer
End Class
