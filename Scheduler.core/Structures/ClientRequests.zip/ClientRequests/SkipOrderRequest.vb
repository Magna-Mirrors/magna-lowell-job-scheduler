﻿<DataContract()>
Public Class SkipOrderRequest
    <DataMember>
    Public Property Lineid As Integer

End Class
