﻿Public MustInherit Class BaseResponse
    Public Sub New()
        Result = 0
        ResultString = String.Empty
    End Sub

    <DataMember()>
    Public Property Result As Integer
    <DataMember()>
    Public Property ResultString As String
End Class
