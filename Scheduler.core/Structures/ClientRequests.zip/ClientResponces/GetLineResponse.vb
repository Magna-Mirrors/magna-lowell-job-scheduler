﻿<DataContract()>
Public Class GetLineResponse
    Inherits BaseResponse

    <DataMember()>
    Public Property LineInfo As Line

    Public Sub New()
        MyBase.New()
    End Sub
End Class
