﻿Imports System.Collections.Generic
Imports System.Runtime.Serialization

<DataContract()>
Public Class GetLinesResponse
    Inherits BaseResponse

    <DataMember()>
    Public Property Lines As List(Of Line)

    Public Sub New()
        MyBase.New()
        Lines = New List(Of Line)()
    End Sub
End Class