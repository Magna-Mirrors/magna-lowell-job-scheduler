﻿<DataContract()>
Public Class GetNextOrderResult
    Inherits BaseResponse

    <DataMember()>
    Public Property Item As PlanItem

    Public Sub New()
        MyBase.New()
        Item = New PlanItem
    End Sub
End Class
