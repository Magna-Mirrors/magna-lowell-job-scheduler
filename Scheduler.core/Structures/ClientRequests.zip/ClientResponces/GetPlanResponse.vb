﻿Imports System.Collections.Generic
Imports System.Runtime.Serialization

<DataContract()>
Public Class GetPlanResponse
    Inherits BaseResponse

    <DataMember()>
    Public Property PlanData As List(Of PlanItem)

    Public Sub New()
        MyBase.New()

        PlanData = New List(Of PlanItem)
    End Sub
End Class