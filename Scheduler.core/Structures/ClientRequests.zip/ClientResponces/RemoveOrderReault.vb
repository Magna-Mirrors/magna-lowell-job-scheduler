﻿<DataContract()>
Public Class RemoveOrderResult
    Inherits BaseResponse

    Public Sub New()
        MyBase.New()
    End Sub
End Class
