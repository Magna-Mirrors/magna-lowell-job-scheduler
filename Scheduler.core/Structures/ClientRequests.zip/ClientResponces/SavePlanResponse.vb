﻿<DataContract>
Public Class SavePlanResponse
    Inherits BaseResponse

    <DataMember>
    Public Property lastLoadDate As DateTime

    Public Sub New()
        MyBase.New()
        ResultString = "0"
        lastLoadDate = DateTime.MinValue
    End Sub

End Class
