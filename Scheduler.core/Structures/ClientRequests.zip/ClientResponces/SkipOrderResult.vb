﻿<DataContract()>
Public Class SkipOrderResult
    Inherits BaseResponse

    <DataMember()> 'return this as the new Schedule item
    Public Property Item As PlanItem
    Public Sub New()
        MyBase.New()
        Item = New PlanItem
    End Sub
End Class
