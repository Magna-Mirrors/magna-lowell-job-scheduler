﻿<DataContract>
Public Class TransactionResult
    Inherits BaseResponse

    Public Sub New()
        MyBase.New()
    End Sub
End Class
