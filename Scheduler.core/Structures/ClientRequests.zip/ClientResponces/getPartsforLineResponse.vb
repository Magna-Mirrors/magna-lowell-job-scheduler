﻿Imports System.Collections.Generic
Imports System.Runtime.Serialization

<DataContract>
Public Class getPartsforLineResponse
    Inherits BaseResponse

    <DataMember>
    Public Property parts As List(Of Part)

    Public Sub New()
        MyBase.New()

        parts = New List(Of Part)()
    End Sub
End Class