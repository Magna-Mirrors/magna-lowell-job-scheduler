﻿Public Enum PartOrderType
    Order = 0
    Built = 1

End Enum