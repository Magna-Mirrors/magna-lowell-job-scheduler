﻿Public Class PartOrder
    Public Property Id As Integer
    Public Property partnumber As String
    Public Property Qty As Integer
    Public Property WC As String
    Public Property PartRequestType As PartOrderType
End Class
