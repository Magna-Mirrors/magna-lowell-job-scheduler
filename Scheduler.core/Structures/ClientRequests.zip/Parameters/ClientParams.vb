﻿<DataContract>
Public Class ClientParams

End Class
